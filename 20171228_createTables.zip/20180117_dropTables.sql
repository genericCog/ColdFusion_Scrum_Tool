USE vaintradb
GO

DROP TABLE		SCRUM_taskNotes
DROP TABLE		SCRUM_storyNotes
DROP TABLE		SCRUM_notes
DROP TABLE		SCRUM_taskLog
DROP TABLE		SCRUM_storyLog
DROP TABLE		SCRUM_sprintLog
DROP TABLE		SCRUM_systemLog
DROP VIEW		SCRUM_productBacklog
DROP VIEW		SCRUM_epics
DROP VIEW		SCRUM_sprintBacklog
DROP TABLE		SCRUM_epicStories
--DROP TRIGGER	SCRUM_sprintStories_DELETE
--DROP TRIGGER	SCRUM_sprintStories_INSERT
DROP TABLE		SCRUM_sprintTasks
DROP TABLE		SCRUM_sprintStories
DROP TABLE		SCRUM_tasks
DROP TABLE		SCRUM_storyPOCs
DROP TABLE		SCRUM_stories
DROP TABLE		SCRUM_sprints
DROP TABLE		SCRUM_statuses
--DROP TABLE	SCRUM_sprintStatuses
--DROP TABLE	SCRUM_backlogStatuses
DROP TABLE		SCRUM_priorities

GO