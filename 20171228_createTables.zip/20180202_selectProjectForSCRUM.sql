USE vaintradb
GO
DECLARE	@story	TABLE (
                	project_name 		VARCHAR(128),
                    description			VARCHAR(MAX),
                    story_points		INT,
                    isEpic				BIT,
                    epic_id				INT,
                    ccb_required		BIT,
                    ccb_approved		BIT,
                    input_date			DATE,
                    backlogStatus_id	INT,
                    sprint_number		INT,
                    sprintStatus_id		INT,
                    priority_id			INT,
                    app_id				INT,
                    input_uid			INT,
                    poc_uid				INT,
                    lead_uid			INT
                )
                
                INSERT	@story	(
                	project_name,
                    description,
                    story_points,
                    isEpic,
                    epic_id,
                    ccb_required,
                    ccb_approved,
                    input_date,
                    backlogStatus_id,
                    sprint_number,
                    sprintStatus_id,
                    priority_id,
                    app_id,
                    input_uid,
                    poc_uid,
                    lead_uid
                )
SELECT	CASE p.project_name
			WHEN '' THEN NULL
			ELSE p.project_name
		END,
		CASE p.description
			WHEN '' THEN NULL
			ELSE p.description
		END,
		p.story_points,
		p.isEpic,
		CASE
			WHEN ISNUMERIC(p.predecessor)=1 AND CAST(p.predecessor AS INT)>=1 THEN CAST(p.predecessor AS INT)
			ELSE NULL
		END AS [epic_id],
		ISNULL(p.ccb_required,0) AS [ccb_required],
		CASE p.ccb_required
			WHEN 1 THEN ISNULL(p.ccb_approved,0)
			ELSE NULL
		END AS [ccb_approved],
		p.input_date,
		CASE p.project_status
			WHEN 'Active'			THEN 2
			WHEN 'Canceled'			THEN 6
			WHEN 'Complete'			THEN 4
			WHEN 'Done'				THEN 3
			WHEN 'In Progress'		THEN 3
			WHEN 'On Hold'			THEN 5
			WHEN 'Product Backlog'	THEN 2
			WHEN 'Scrum Backlog'	THEN 3
			WHEN 'Sprint Backlog'	THEN 3
			ELSE 1
		END AS backlogStatus_id,
		p.sprint_number,
		CASE 
			WHEN p.sprint_number IS NULL	THEN NULL
			ELSE	CASE p.project_status
					WHEN 'In Progress'	THEN 8
					WHEN 'Done'			THEN 10
					WHEN 'Complete'		THEN 10
					WHEN 'Canceled'		THEN 11
					ELSE 7
					END
		END AS sprintStatus_id,
		CASE p.project_priority
			WHEN 'High'		THEN 3
			WHEN 'Hot-Box'	THEN 4
			WHEN 'Low'		THEN 1
			ELSE 2
		END AS priority_id,
		av.app_id,
		ai.id AS [input_uid],
		ai2.id AS [poc_uid],
		ai3.id AS [lead_uid]
		
		
FROM	projects p
LEFT OUTER JOIN apps_valid av ON p.active_app=CAST(av.app_id AS varchar)
LEFT OUTER JOIN account_info ai ON CASE p.input_user WHEN '' THEN NULL WHEN '0' THEN NULL ELSE p.input_user END=ai.cac_edipi
LEFT OUTER JOIN account_info ai2 ON CASE p.requested_by WHEN '' THEN NULL WHEN '0' THEN NULL ELSE p.requested_by END=ai2.cac_edipi
LEFT OUTER JOIN account_info ai3 ON CASE p.project_lead WHEN '' THEN NULL WHEN '0' THEN NULL ELSE p.project_lead END=ai3.cac_edipi

