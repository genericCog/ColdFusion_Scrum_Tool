USE vaintradb
GO
--BEGIN TRAN
--BEGIN TRY
--	INSERT INTO CJS_notes (contents,added_by)
--	VALUES ('test note to confirm sql functionality',4517)

--	DECLARE @noteID INT
--	SET @noteID = SCOPE_IDENTITY()

--	INSERT INTO CJS_storyNotes (story_id,note_id)
--	VALUES (1,@noteID)
--	COMMIT TRAN
--END TRY
--BEGIN CATCH
--	ROLLBACK TRAN
--END CATCH

DECLARE @insertedNote TABLE (id INT)

INSERT CJS_notes (contents,added_by)
	OUTPUT inserted.id INTO @insertedNote
VALUES ('Test using the Output Statement of an Insert Statement with a second variable declaration',4517)

DECLARE @noteID INT
SET		@noteID = (SELECT TOP 1 id FROM @insertedNote)

INSERT CJS_storyNotes (story_id,note_id)
VALUES (1,@noteID)