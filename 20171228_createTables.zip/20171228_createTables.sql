USE vaintradb
GO

BEGIN TRAN
BEGIN TRY
	CREATE TABLE CJS_scrumStatuses (
		id		INT			IDENTITY PRIMARY KEY,
		name	VARCHAR(16) NOT NULL UNIQUE
	)

	INSERT	INTO CJS_scrumStatuses (name)
	VALUES	('DONE'),('TO DO'),('IN PROGRESS'),('BLOCKED'),('PENDING'),('READY'),('ECLIPSED'),('CANCELLED')

	CREATE TABLE CJS_scrumPriorities (
		id		INT			IDENTITY PRIMARY KEY,
		name	varchar(16)	NOT NULL UNIQUE,
		value	INT			NOT NULL
	)

	INSERT	INTO CJS_scrumPriorities (name,value)
	VALUES	('VERY LOW',1),('LOW',2),('NORMAL',3),('HIGH',4),('VERY HIGH',5),('CRITICAL',6)

	CREATE TABLE CJS_sprints (
		id			INT				IDENTITY PRIMARY KEY,
		date_start	DATETIME		NOT NULL,
		date_end	DATETIME		NOT NULL,
		CONSTRAINT	SPRINTS_END_GT_START	CHECK(date_end>date_start)
	)

	CREATE TABLE CJS_stories (
		id				INT					IDENTITY PRIMARY KEY,
		name			VARCHAR(256)		NOT NULL,
		[description]	VARCHAR(MAX)		NULL,
		storypoints		INT					NOT NULL DEFAULT(100),
		priority_id		INT					NOT NULL REFERENCES CJS_scrumPriorities(id),
		status_id		INT					NOT NULL REFERENCES CJS_scrumStatuses(id),
		added_on		DATETIME			NOT NULL DEFAULT(GETDATE()),
		added_by		INT					NOT NULL REFERENCES account_info(id),
		completed_on	DATETIME			NULL,
		completed_by	INT					NULL REFERENCES account_info(id),
		CONSTRAINT		STORY_SP_VALUE			CHECK(storypoints IN (1,2,3,5,8,13,21,34,55,89,100)),
		CONSTRAINT		STORY_STATUS_DONE			CHECK(status_id<>1 OR (completed_on IS NOT NULL AND completed_by IS NOT NULL)),
		CONSTRAINT		STORY_COMPELTED_GT_ADDED	CHECK(completed_on IS NULL OR completed_on >added_on)
	)

	CREATE TABLE CJS_sprintBacklog (
		sprint_id	INT	NOT NULL	REFERENCES CJS_sprints(id),
		story_id	INT	NOT NULL	REFERENCES CJS_stories(id),
		CONSTRAINT	SBL_SPRINT_STORY	UNIQUE(sprint_id,story_id)
	)

	CREATE TABLE CJS_tasks (
		id				INT					IDENTITY PRIMARY KEY,
		story_id		INT					NOT NULL REFERENCES CJS_stories(id),
		name			VARCHAR(256)		NOT NULL,
		[description]	VARCHAR(MAX)		NULL,
		status_id		INT					NOT NULL REFERENCES CJS_scrumStatuses(id),
		added_on		DATETIME			NOT NULL DEFAULT(GETDATE()),
		added_by		INT					NOT NULL REFERENCES account_info(id),
		completed_on	DATETIME			NULL,
		completed_by	INT					NULL REFERENCES account_info(id),
		CONSTRAINT		TASK_STATUS_DONE			CHECK(status_id<>1 OR (completed_on IS NOT NULL AND completed_by IS NOT NULL)),
		CONSTRAINT		TASK_COMPLETED_GT_ADDED	CHECK(completed_on IS NULL OR completed_on>added_on),
		CONSTRAINT		TASK_STORY_NAME			UNIQUE(story_id,name)
	)

	CREATE TABLE CJS_notes (
		id			INT				IDENTITY PRIMARY KEY,
		contents	VARCHAR(MAX)	NOT NULL,
		added_on	DATETIME		NOT NULL DEFAULT(GETDATE()),
		added_by	INT				NOT NULL REFERENCES account_info(id)
	)

	CREATE TABLE CJS_sprintNotes (
		sprint_id	INT	NOT NULL REFERENCES CJS_sprints(id),
		note_id		INT NOT NULL REFERENCES CJS_notes(id)
	)

	CREATE TABLE CJS_storyNotes (
		story_id	INT	NOT NULL REFERENCES CJS_stories(id),
		note_id		INT NOT NULL REFERENCES CJS_notes(id)
	)

	CREATE TABLE CJS_taskNotes (
		task_id	INT	NOT NULL REFERENCES CJS_tasks(id),
		note_id		INT NOT NULL REFERENCES CJS_notes(id)
	)
	
	CREATE TABLE CJS_epics (
		id				INT				IDENTITY PRIMARY KEY,
		name			VARCHAR(256)	NOT NULL,
		[description]	VARCHAR(MAX)	NULL,
		added_on		DATETIME		NOT NULL DEFAULT(GETDATE()),
		added_by		INT				NOT NULL REFERENCES account_info(id)
	)
	
	CREATE TABLE CJS_epicStories (
		epic_id		INT					NOT NULL REFERENCES CJS_epics(id),
		story_id	INT					NOT NULL REFERENCES CJS_stories(id),
		CONSTRAINT	UNIQUE_EPIC_STORY	UNIQUE(epic_id,story_id)
	)
	
	CREATE TABLE CJS_epicNotes (
		epic_id		INT		NOT NULL REFERENCES CJS_epics(id),
		note_id		INT		NOT NULL REFERENCES CJS_notes(id)
	)
	
	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
END CATCH