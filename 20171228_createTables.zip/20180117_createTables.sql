USE vaintradb
GO

--Create priorities reference table
CREATE TABLE SCRUM_priorities (
	id			INT				PRIMARY KEY IDENTITY,
	name		VARCHAR(128)	NOT NULL UNIQUE,
	heirarchy	INT				NOT NULL DEFAULT 0,
	active		BIT				NOT NULL DEFAULT 1
)
GO

--Populate table with default values
INSERT INTO SCRUM_priorities (name,heirarchy)
VALUES
	('Low',0),
	('Normal',1),
	('High',2),
	('Hot-Box',3)
GO

--Create statuses reference table
CREATE TABLE SCRUM_statuses (
	id		INT				PRIMARY KEY IDENTITY,
	name	VARCHAR(128)	NOT NULL UNIQUE,
	active	BIT				NOT NULL DEFAULT 1,
	backlog	BIT				NOT NULL DEFAULT 0,
	step	INT				NOT NULL DEFAULT 1,
	color	VARCHAR(6)		NOT NULL DEFAULT 'fff'
)
GO

--populate with default values
INSERT INTO SCRUM_statuses (name,backlog,step,color)
VALUES
	('pending',1,1,'ccc'),
	('ready',1,3,'ff0'),
	('in current sprint',1,4,'00f'),
	('completed',1,5,'0f0'),
	('on hold',1,2,'888'),
	('cancelled',1,6,'000'),
	
	('To-Do',0,1,'ccc'),
	('In Progress',0,2,'00f'),
	('Blocked',0,3,'f00'),
	('Done',0,4,'0f0'),
	('Removed',0,5,'000')
GO

--Create backlogStatuses reference table
--CREATE TABLE SCRUM_backlogStatuses (
--	id		INT				PRIMARY KEY IDENTITY,
--	name	VARCHAR(128)	NOT NULL UNIQUE,
--	active	BIT				NOT NULL DEFAULT 1,
--	color	VARCHAR(6)		NOT NULL DEFAULT 'fff'
--)
--GO

--populate with default values
--INSERT INTO SCRUM_backlogStatuses (name,color)
--VALUES 
--	('pending','ccc'),
--	('ready','ff0'),
--	('in current sprint','00f'),
--	('completed','0f0'),
--	('on hold','888'),
--	('cancelled','000')
--GO

--Create sprintStatuses reference table
--CREATE TABLE SCRUM_sprintStatuses (
--	id		INT				PRIMARY KEY IDENTITY,
--	name	VARCHAR(128)	NOT NULL UNIQUE,
--	active	BIT				NOT NULL DEFAULT 1,
--	color	VARCHAR(6)		NOT NULL DEFAULT 'fff'	
--)
--GO

--populate with default values
--INSERT INTO SCRUM_sprintStatuses (name,color)
--VALUES 
--	('to-do','ccc'),
--	('in progress','00f'),
--	('blocked','f00'),
--	('completed','0f0'),
--	('removed','000')
--GO

--Create sprints table
CREATE TABLE SCRUM_sprints (
	id					INT				PRIMARY KEY IDENTITY,
	name				VARCHAR(128)	NULL,
	goal				VARCHAR(MAX)	NULL,
	startDate			DATETIME		NOT NULL UNIQUE,
	endDate				DATETIME		NOT NULL,
	storypointsTarget	INT				NOT NULL DEFAULT 1,
	
	CONSTRAINT SPRINTS_EDGTSD	CHECK(endDate>startDate),
	CONSTRAINT SPRINTS_SPCGT0	CHECK(storypointsTarget>0)
)
GO

--Create stories table
CREATE TABLE SCRUM_stories (
	id							INT				PRIMARY KEY IDENTITY,
	name						VARCHAR(128)	NOT NULL,
	[description]				VARCHAR(MAX)	NULL,
	storypoints					INT				NOT NULL DEFAULT 100,
	epic						BIT				NOT NULL DEFAULT 0,
	backlogStatus_id			INT				NOT NULL REFERENCES SCRUM_statuses(id) DEFAULT 1,
	--poc_id						INT				NOT NULL REFERENCES account_info(id),
	associatedApplication_id	INT				NULL REFERENCES apps_valid(app_id),
	priority_id					INT				NOT NULL REFERENCES SCRUM_priorities(id) DEFAULT 2,
	ccbRequired					BIT				NOT NULL DEFAULT 0,
	ccbApproved					BIT				NULL,
	createdDate					DATETIME		NOT NULL DEFAULT GETDATE(),
	
	CONSTRAINT STORIES_SPGT0	CHECK(storypoints>0),
	CONSTRAINT STORIES_CCB		CHECK(ccbRequired=0 OR ccbApproved IS NOT NULL)
)
GO

--create a table to hold values for POCs associated with a story
CREATE TABLE SCRUM_storyPOCs (
	story_id	INT	NOT NULL REFERENCES SCRUM_stories(id),
	poc_id		INT	NOT NULL REFERENCES account_info(id),
	isPrimary	BIT	NOT NULL DEFAULT 0,
	
	CONSTRAINT	POCS_UNIQUE	UNIQUE(story_id,poc_id)
)
GO

--create a filtered index on the story_id column of storyPOCs table to enforce having 1 and only 1 primary POC per story
CREATE UNIQUE INDEX [U_storyPOCs_storyid]
ON		SCRUM_storyPOCs(story_id)
WHERE	isPrimary=1
GO


--Create tasks table
CREATE TABLE SCRUM_tasks (
	id				INT				PRIMARY KEY IDENTITY,
	name			VARCHAR(128)	NOT NULL,
	[description]	VARCHAR(MAX)	NULL,
	storypoints		INT				NOT NULL DEFAULT 100,
	story_id		INT				NOT NULL REFERENCES SCRUM_stories(id),
	createdDate		DATETIME		NOT NULL DEFAULT GETDATE(),
	
	CONSTRAINT	TASKS_SPGT0			CHECK(storypoints>0)	
)
GO

--create sprintStories link table
CREATE TABLE SCRUM_sprintStories (
	sprint_id		INT	NOT NULL REFERENCES SCRUM_sprints(id),
	story_id		INT	NOT NULL REFERENCES SCRUM_stories(id),
	sprintStatus_id	INT	NOT NULL REFERENCES SCRUM_statuses(id) DEFAULT 7,
	taskLead_id		INT	NULL REFERENCES account_info(id),
	
	CONSTRAINT	SSTORIES_UNIQUE	UNIQUE(sprint_id,story_id)
)
GO

--create sprintTasks link table
CREATE TABLE SCRUM_sprintTasks (
	sprint_id		INT NOT NULL REFERENCES SCRUM_sprints(id),
	task_id			INT	NOT NULL REFERENCES SCRUM_tasks(id),
	sprintStatus_id	INT	NOT NULL REFERENCES SCRUM_statuses(id) DEFAULT 7,
	taskLead_id		INT	NULL REFERENCES account_info(id),
	
	CONSTRAINT	STASKS_UNIQUE	UNIQUE(sprint_id,task_id)
)
GO

--create insert and delete triggers for sprintStories table to insert/delete children tasks from sprinttasks table
--PER STIGS: CANNOT USE stored PROCS or TRIGGERS, will need to handle addition/removal of related tasks from CF code
--CREATE TRIGGER SCRUM_sprintStories_INSERT
--	ON	SCRUM_sprintStories
--	AFTER INSERT
--	AS
--	INSERT INTO SCRUM_sprintTasks (sprint_id,task_id)
--	SELECT	INSERTED.sprint_id,
--			SCRUM_tasks.id
--	FROM	INSERTED
--	LEFT OUTER JOIN SCRUM_tasks ON INSERTED.story_id=SCRUM_tasks.story_id
--GO

--CREATE TRIGGER SCRUM_sprintStories_DELETE
--	ON	SCRUM_sprintStories
--	AFTER DELETE
--	AS
--	DELETE	SCRUM_sprintTasks
--	WHERE	CAST(sprint_id AS VARCHAR)+'_'+CAST(task_id AS VARCHAR) IN (SELECT CAST(sprint_id AS VARCHAR)+'_'+CAST(task_id AS VARCHAR) FROM DELETED)
--GO

--Create table to link stories marked as epic to associated children
--**Cannot enforce constraint of story of id epic_id being marked as epic without a trigger/stored proc nor can
--it be enforced that a story with children tasks cannot be marked as epic or tasks be added to epic story
--enforcement of these constraints will have to fall to CF code
CREATE TABLE SCRUM_epicStories (
	epic_id		INT	NOT NULL REFERENCES SCRUM_stories(id),
	story_id	INT	NOT NULL REFERENCES SCRUM_stories(id),
	
	CONSTRAINT ESTORIES_UNIQUE UNIQUE(epic_id,story_id)
)
GO

--create sprintBacklog view combining sprintstories and sprinttasks
CREATE VIEW SCRUM_sprintBacklog AS (
		SELECT	SS.sprint_id		AS [sprint_id],
				'story'				AS [type],
				SS.story_id			AS [item_id],
				SS.sprintStatus_id	AS [sprintStatus_id],
				SS.taskLead_id		AS [taskLead_id],
				CASE
					--select the higher of; storypoint value assigned to parent story, or sum of all storypoint values assigned to children tasks
					WHEN	S.storypoints
							>
							ISNULL((SELECT	SUM(T.storypoints)
							FROM	SCRUM_tasks AS T
							WHERE	T.story_id=SS.story_id),0)
					THEN	S.storypoints
					ELSE	(SELECT	SUM(T.storypoints)
							FROM	SCRUM_tasks AS T
							WHERE	T.story_id=SS.story_id)
				END AS [storypoints]
		FROM	SCRUM_sprintStories AS SS
		LEFT OUTER JOIN SCRUM_stories AS S ON SS.story_id=S.id
	UNION
		SELECT	ST.sprint_id		AS [sprint_id],
				'task'				AS [type],
				ST.task_id			AS [item_id],
				ST.sprintStatus_id	AS [sprintStatus_id],
				ST.taskLead_id		AS [taskLead_id],
				T.storypoints		AS [storypoints]
		FROM	SCRUM_sprintTasks AS ST
		LEFT OUTER JOIN SCRUM_tasks AS T ON T.id=ST.task_id
)
GO



--Create a view specifically for epics, using a similar methodology for the sprintbacklog view in determining storypoint total
CREATE VIEW SCRUM_epics AS (
	SELECT	S.id						AS [id],
			S.name						AS [name],
			S.[description]				AS [description],
			CASE
				WHEN
					S.storypoints
					>
					ISNULL((SELECT	SUM(CS.storypoints)
							FROM	SCRUM_stories AS CS
							WHERE	CS.id IN (	SELECT	ES.story_id
												FROM	SCRUM_epicStories AS ES
												WHERE	ES.epic_id=S.id)),0)
				THEN
					S.storypoints
				ELSE
					(SELECT	SUM(CS.storypoints)
					FROM	SCRUM_stories AS CS
					WHERE	CS.id IN (	SELECT	ES.story_id
										FROM	SCRUM_epicStories AS ES
										WHERE	ES.epic_id=S.id))
			END							AS [storypoints],
			--S.poc_id					AS [poc_id],
			S.associatedApplication_id	AS [associatedApplication_id],
			S.priority_id				AS [priority_id],
			S.backlogStatus_id			AS [backlogStatus_id],
			S.ccbRequired				AS [ccbRequired],
			S.ccbApproved				AS [ccbApproved]
	FROM	SCRUM_stories AS S
	WHERE	S.epic=1
)
GO

--create a productBacklog view
CREATE VIEW SCRUM_productBacklog AS (
	SELECT	S.id						AS [id],
			S.name						AS [name],
			S.[description]				AS [description],
			S.storypoints				AS [storypoints],
			--S.poc_id					AS [poc_id],
			S.associatedApplication_id	AS [associatedApplication_id],
			S.priority_id				AS [priority_id],
			S.backlogStatus_id			AS [backlogStatus_id],
			S.ccbRequired				AS [ccbRequired],
			S.ccbApproved				AS [ccbApproved],
			ES.epic_id					AS [epic_id]
	FROM	SCRUM_stories AS S
	LEFT OUTER JOIN SCRUM_epicStories AS ES ON S.id=ES.story_id
	WHERE	S.epic=0
)
GO

--Create a systemLog table to hold system generated log entries (ie 'user 1234 changed status of story 123 from x to y')
CREATE TABLE SCRUM_systemLog (
	id		INT				PRIMARY KEY IDENTITY,
	content	VARCHAR(MAX)	NOT NULL,
	logDate	DATETIME		NOT NULL DEFAULT GETDATE()
)
GO

--create link tables for system log entries relating to sprints, stories, and tasks
CREATE TABLE SCRUM_sprintLog (
	sprint_id	INT	NOT NULL REFERENCES SCRUM_sprints(id),
	log_id		INT	NOT NULL REFERENCES SCRUM_systemLog(id)
)
GO
CREATE TABLE SCRUM_storyLog (
	story_id	INT NOT NULL REFERENCES SCRUM_stories(id),
	log_id		INT NOT NULL REFERENCES SCRUM_systemLog(id)
)
GO
CREATE TABLE SCRUM_taskLog (
	task_id		INT NOT NULL REFERENCES SCRUM_tasks(id),
	log_id		INT NOT NULL REFERENCES SCRUM_systemLog(id)
)
GO

--Create a user defined notes table to hold user generated updates and notes related to stories (and by extension epics) and tasks
CREATE TABLE SCRUM_notes (
	id			INT				PRIMARY KEY IDENTITY,
	content		VARCHAR(MAX)	NOT NULL,
	addedDate	DATETIME		NOT NULL DEFAULT GETDATE(),
	addedBy_id	INT				NOT NULL REFERENCES account_info(id)
)
GO
CREATE TABLE SCRUM_storyNotes (
	story_id	INT	NOT NULL REFERENCES SCRUM_stories(id),
	note_id		INT	NOT NULL REFERENCES SCRUM_notes(id)
)
GO
CREATE TABLE SCRUM_taskNotes (
	task_id	INT	NOT NULL REFERENCES SCRUM_tasks(id),
	note_id	INT	NOT NULL REFERENCES SCRUM_notes(id)
)
GO