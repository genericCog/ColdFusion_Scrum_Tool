20180720
Files on this disk represent work completed towards creation of an in-house
sprint board for tracking tasks using the Agile SCRUM methodology

POC: Chris Scupski RQOC 937-938-4626 christopher.scupski.ctr@us.af.mil

Some of the pages MAY require setting variables in the application or session
scopes to function properly (it's been a while since I touched the files
so I don't really remember)

The 20171228_DB_schema.xlsx file is largely correct, however does not 
reflect changes made to the database following 1/19/2018
A more complete db schema is outlined in Scrum_database_tables_outline.docx

20171228_createTables.sql should not be used (was initial test version of tables)
Instead 20180117_createTables.sql is the correct table creation script

sprintBacklog.cfm is the sprint backlog page that was being built, to test
however will require some sprint/story entries in the appropriate database
tables.

StoryPointIndicatorTest.html was exploring the possibility of displaying the status of a story's tasks
as a graphic around the story's point total, and the work on this page had led
to incorporating a progress bar for the sprint on the main sprint backlog page,
however, that version of sprintBacklog.cfm was not copied from the previous dev server
which was shut down.

scrumImport.cfm and .cfc were used to import data from the existing projects table for RQOC
into the scrum tables for testing purposes and would have eventually been used to migrate
from the current tool to the new one.