//namespaces required to be able to dynamically create svg elements, and specifically, svg use elements that utilize the xlink:href attribute to include defined symbols
var NS={
	"svg":"http://www.w3.org/2000/svg",
	"xmlns":"http://www.w3.org/2000/xmlns/",
	"xlink":"http://www.w3.org/1999/xlink"
	};

//requires use of CFCAJAXRequest library and a custom CFC JSON parser function found in head of sprintBacklog.cfm
var devs=JSON.parseCFC(CFCInvoke("scrumTools","getWebAdmins"));

Element.prototype.appendOption=function(v,d,s){
	v=v?v:"";
	d=d?d:v;
	var option=document.createElement("option");
	option.setAttribute("value",v);
	if(s){
		option.selected=true;
		};
	var txt=document.createTextNode(d);
	option.appendChild(txt);
	this.appendChild(option);
	}
Element.prototype.appendNote=function(n,d,c){
	var dt=document.createElement("dt");
	var dd=document.createElement("dd");
	var tn_dt=document.createTextNode(n+" "+d);
	var tn_dd=document.createTextNode(c);
	dt.appendChild(tn_dt);
	dd.appendChild(tn_dd);
/*	this.appendChild(dt);
	this.appendChild(dd);*/
	this.insertBefore(dd,this.firstChild);
	this.insertBefore(dt,this.firstChild);
	}

/*
*	define a 'sprint' object to hold all stories/tasks within the referenced sprint and provide functions to sort
*	and change those items
*/
function Sprint(oSprint){
	this.id=oSprint.id;
	this.stories={};
	this.ready=[];
	this.toDo=[];
	this.inProgress=[];
	this.blocked=[];
	this.done=[];
	this.points=oSprint.points;
	this.totalPoints=0;
	
	for(var i in oSprint.stories){
		var name=oSprint.stories[i].type+"_"+oSprint.stories[i].id;
		this.stories[name]=new StoryItem(oSprint.stories[i]);
		switch(this.stories[name].sprintStatus){
			case 7: //to-do
				this.toDo.push(name);
				break;
			case 8: //in progress
				this.inProgress.push(name);
				break;
			case 9: //blocked
				this.blocked.push(name);
				break;
			case 10: //done
				this.done.push(name);
				break;
			default: //ready (null) or removed
				this.ready.push(name);
				break;
			}
		}//end loop
	
	};
	
function StoryItem(oStory){
	this.id=oStory.id;
	this.type=oStory.type;
	this.sprintStatus=oStory.sprintStatus;
	this.storyPoints=oStory.storyPoints;
	this.notes=[];
	for(var note in oStory.notes){
		this.notes.push(new Note(oStory.notes[note]));
		}
	//create the actual html div that is displayed on the page
	this.div=document.createElement("div");
	this.div.id=this.type+"_"+this.id;
	this.div.classList.add(this.type);
	if(oStory.priority_id==4){
		this.div.classList.add("hotbox");
		}
	//create storypoints indicator
	var sp=document.createElementNS(NS.svg,"svg");
		sp.setAttribute("class","storypoint");
		sp.setAttribute("width","50px");
		sp.setAttribute("height","50px");
		sp.setAttribute("viewBox","0 0 100 100");
		sp.setAttributeNS(NS.xmlns,"xmlns:xlink",NS.xlink);
		var sp_use=document.createElementNS(NS.svg,"use");
			sp_use.setAttributeNS(NS.xlink,"xlink:href","#icon_indicator");
			sp_use.setAttribute("fill","#fff");
		/*if progress bars are to be added for stories create path elements here and append to sp*/
		sp.appendChild(sp_use);
	this.div.appendChild(sp);
	var info_div=document.createElement("div");
		info_div.classList.add("info_wrapper");
		var name_h4=document.createElement("h4");
			var name_parents="";
			for(var i in oStory.parents){
				name_parents+=oStory.parents[i]+"/";
				}
			var name_parentsTxt=document.createTextNode(name_parents);
			var name_nameTxt=document.createTextNode(oStory.name);
			var name_span=document.createElement("span");
				name_span.appendChild(name_parentsTxt);
			var name_br=document.createElement("br");
			name_h4.appendChild(name_span);
			name_h4.appendChild(name_br);
			name_h4.appendChild(name_nameTxt);
		info_div.appendChild(name_h4);
		
		//create the status change control buttons
		var controls_div=document.createElement("div");
			controls_div.classList.add("controls");
			controls_div.appendChild(svgButton("Add to Sprint","updateStatus('"+this.type+"_"+this.id+"',7)","20px","20px","0 0 100 100",true,"#icon_download","rotate(-90 50 50)"));
			controls_div.appendChild(svgButton("To-do","updateStatus('"+this.type+"_"+this.id+"',7)","20px","20px","0 0 150 100",false,"#arrow_double","rotate(180 75 50)"));
			controls_div.appendChild(svgButton("In Progress","updateStatus('"+this.type+"_"+this.id+"',8)","20px","20px","0 0 100 100",true,"#arrow_single",false));
			controls_div.appendChild(svgButton("Blocked","updateStatus('"+this.type+"_"+this.id+"',9)","20px","20px","0 0 100 100",true,"#icon_blocked",false));
			controls_div.appendChild(svgButton("Done","updateStatus('"+this.type+"_"+this.id+"',10)","20px","20px","0 0 100 100",true,"#checkmark",false));
			switch(this.type){
				case "story":
					controls_div.appendChild(svgButton("Remove from Sprint","updateStatus('"+this.type+"_"+this.id+"',11)","20px","20px","0 0 100 100",true,"#icon_upload","rotate(-90 50 50)"));
					controls_div.appendChild(svgButton("Add Task","openNewTask()","20px","20px","0 0 100 100",true,"#icon_add",false));
					break;
				case "task":
					controls_div.appendChild(svgButton("Delete Task","","20px","20px","0 0 100 100",true,"#icon_add","rotate(45 50 50)"));
					break;
			}
		info_div.appendChild(controls_div);
		
		//create task lead select dropdown
		var tl_select=document.createElement("select");
			tl_select.setAttribute("title","Task Lead");
			tl_select.appendOption();
			var leadInDevs=false;
			for(var i in devs.users){
				var s=devs.users[i].id==oStory.lead?true:false;
				leadInDevs=leadInDevs?leadInDevs:s;
				tl_select.appendOption(devs.users[i].id,devs.users[i].name,s);
				};
			if(!leadInDevs&&oStory.lead!=""){
				var data=new FormData();
					data.append("user_id",oStory.lead);
				var nonDevUser=JSON.parseCFC(CFCInvoke("scrumTools","getWebAdmins",data));
				if(nonDevUser.users.length>0){
					tl_select.appendOption(nonDevUser.users[0].id,nonDevUser.users[0].name,true);
					}
				}
		info_div.appendChild(tl_select);
	this.div.appendChild(info_div);

	var detail_div=document.createElement("div");
		detail_div.classList.add("details");
		var fset_desc=document.createElement("fieldset");
			fset_desc.classList.add("description");
			var tarea_desc=document.createElement("textarea");
				tarea_desc.id="descEntry_"+this.type+"_"+this.id;
				tarea_desc.setAttribute("placeholder","Type here to edit the description");
				tarea_desc.value=oStory.description;
			fset_desc.appendChild(tarea_desc);
			var b_saveDesc=document.createElement("button");
				b_saveDesc.setAttribute("title","Save Changes");
				b_saveDesc.setAttribute("type","button");
				b_saveDesc.setAttribute("onClick","updateDescription('"+this.type+"_"+this.id+"')");
				var svg_save=document.createElementNS(NS.svg,"svg");
					svg_save.setAttributeNS(NS.xmlns,"xmlns:xlink",NS.xlink);
					svg_save.setAttribute("width","1em");
					svg_save.setAttribute("height","1em");
					svg_save.setAttribute("viewBox","0 0 100 100");
					var use_save=document.createElementNS(NS.svg,"use");
						use_save.setAttributeNS(NS.xlink,"xlink:href","#icon_save");
					svg_save.appendChild(use_save);
				b_saveDesc.appendChild(svg_save);
			fset_desc.appendChild(b_saveDesc);
		detail_div.appendChild(fset_desc);
		
		var fset_note=document.createElement("fieldset");
			fset_note.classList.add("note");
			var tarea_note=document.createElement("textarea");
				tarea_note.id="noteEntry_"+this.type+"_"+this.id;
				tarea_note.setAttribute("placeholder","Type here to add a note");
			fset_note.appendChild(tarea_note);
			var b_addNote=document.createElement("button");
				b_addNote.setAttribute("title","Add Note");
				b_addNote.setAttribute("type","button");
				b_addNote.setAttribute("onClick","addNote('"+this.type+"_"+this.id+"')");
				var svg_add=document.createElementNS(NS.svg,"svg");
					svg_add.setAttributeNS(NS.xmlns,"xmlns:xlink",NS.xlink);
					svg_add.setAttribute("width","1em");
					svg_add.setAttribute("height","1em");
					svg_add.setAttribute("viewBox","0 0 100 100");
					var use_add=document.createElementNS(NS.svg,"use");
						use_add.setAttributeNS(NS.xlink,"xlink:href","#icon_add");
					svg_add.appendChild(use_add);
				b_addNote.appendChild(svg_add);
			fset_note.appendChild(b_addNote);
		detail_div.appendChild(fset_note);
		
		var notes_dl=document.createElement("dl");
			notes_dl.id="notes_"+this.type+"_"+this.id;
			notes_dl.classList.add("notes");
			for(var i in this.notes){
				notes_dl.appendNote(this.notes[i].user,this.notes[i].date,this.notes[i].content)
				}
		detail_div.appendChild(notes_dl);
		
		var expand_notes=document.createElement("button");
			expand_notes.classList.add("expand");
			expand_notes.setAttribute("type","button");
			expand_notes.setAttribute("title","Expand Notes");
			expand_notes.setAttribute("onClick","expand('notes_"+this.type+"_"+this.id+"')");
				var svg_expandN=document.createElementNS(NS.svg,"svg");
					svg_expandN.setAttributeNS(NS.xmlns,"xmlns:xlink",NS.xlink);
					svg_expandN.setAttribute("width","10px");
					svg_expandN.setAttribute("height","10px");
					svg_expandN.setAttribute("viewBox","0 0 100 100");
					var path_N=document.createElementNS(NS.svg,"path");
						path_N.setAttribute("fill","#444");
						path_N.setAttribute("d","M100,0v100h-100z");
				svg_expandN.appendChild(path_N);
			expand_notes.appendChild(svg_expandN);
		detail_div.appendChild(expand_notes);
	this.div.appendChild(detail_div);
	
	var expand_details=document.createElement("button");
		expand_details.classList.add("expand");
		expand_details.setAttribute("type","button");
		expand_details.setAttribute("title","Show Details");
		expand_details.setAttribute("onClick","expand('"+this.type+"_"+this.id+"')");
			var svg_expandD=document.createElementNS(NS.svg,"svg");
				svg_expandD.setAttributeNS(NS.xmlns,"xmlns:xlink",NS.xlink);
				svg_expandD.setAttribute("width","10px");
				svg_expandD.setAttribute("height","10px");
				svg_expandD.setAttribute("viewBox","0 0 100 100");
				var path_D=document.createElementNS(NS.svg,"path");
					path_D.setAttribute("fill","#444");
					path_D.setAttribute("d","M100,0v100h-100z");
			svg_expandD.appendChild(path_D);
		expand_details.appendChild(svg_expandD);
	this.div.appendChild(expand_details);
	
	//create storypoints input element inserted here to avoid z-indexing issues
	var sp_input=document.createElement("input");
		sp_input.id="spEntry_"+this.type+"_"+this.id;
		sp_input.setAttribute("onBlur","updateStoryPoints('"+this.type+"_"+this.id+"')");
		sp_input.setAttribute("type","text");
		sp_input.setAttribute("title","Storypoints");
		sp_input.value=oStory.storyPoints;
	this.div.appendChild(sp_input);
	};

function svgButton(t,oc,w,h,vb,par,xl,tr){
	vb=vb?vb:"0 0 100 100";
	var b=document.createElement("button");
		b.setAttribute("type","button");
		b.setAttribute("title",t);
		b.setAttribute("onClick",oc);
	var svg=document.createElementNS(NS.svg,"svg");
		svg.setAttributeNS(NS.xmlns,"xmlns:xlink",NS.xlink);
		svg.setAttribute("width",w);
		svg.setAttribute("height",h);
		svg.setAttribute("viewBox",vb);
		if(!par){
			svg.setAttribute("preserveAspectRatio","none");
			}
		var use=document.createElementNS(NS.svg,"use");
			use.setAttributeNS(NS.xlink,"xlink:href",xl);
			if(tr){
				use.setAttribute("transform",tr);
				}
		svg.appendChild(use);
	b.appendChild(svg);
	return b;
	}

function Note(oNote){
	this.id=oNote.id;
	this.content=oNote.content;
	this.date=oNote.date;
	this.user=oNote.user;
	};