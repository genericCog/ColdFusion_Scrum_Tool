USE vaintradb
GO

--INSERT INTO SCRM_sprints (name,goal,startDate,endDate)
--VALUES ('test sprint 1','to test the triggers for sprintstories','1/17/2018','1/24/2018')
--INSERT INTO SCRM_sprints (name,goal,startDate,endDate)
--VALUES ('test sprint 2','to test the triggers for sprintstories','1/24/2018','1/31/2018')

--INSERT INTO SCRM_stories (name,description,storypoints,poc_id)
--VALUES ('test story 1','just a test story',8,4517)

--INSERT INTO SCRM_tasks (name,description,storypoints,story_id)
--VALUES ('test task 1','just a test',8,1),('test task 2','just a test',21,1)

--SELECT * FROM SCRM_sprints
--SELECT * FROM SCRM_stories
--SELECT * FROM SCRM_tasks

--INSERT INTO SCRM_sprintStories (sprint_id,story_id)
--VALUES (1,1)
--INSERT INTO SCRM_sprintStories (sprint_id,story_id)
--VALUES (2,1)
--DELETE SCRM_sprintStories
--WHERE sprint_id=2 AND story_id=1

--INSERT INTO SCRM_sprintStories (sprint_id,story_id)
--VALUES (2,1),(1,1)

--SELECT * FROM SCRM_sprintStories
--SELECT * FROM SCRM_sprintTasks

	SELECT	SS.sprint_id		AS [sprint_id],
			'story'				AS [type],
			SS.story_id			AS [item_id],
			SS.sprintStatus_id	AS [sprintStatus_id],
			SS.taskLead_id		AS [taskLead_id],
			CASE 
				WHEN	(SELECT TOP 1 S.storypoints
						FROM	SCRM_stories AS S
						WHERE	S.id=SS.story_id)
						>
						(SELECT	SUM(T.storypoints)
						FROM	SCRM_tasks AS T
						WHERE	T.story_id=SS.story_id)
				THEN
					(SELECT TOP 1 S.storypoints
						FROM	SCRM_stories AS S
						WHERE	S.id=SS.story_id)
				ELSE
					(SELECT	SUM(T.storypoints)
						FROM	SCRM_tasks AS T
						WHERE	T.story_id=SS.story_id)
			END AS [storypoints]
	FROM SCRM_sprintStories AS SS
UNION
	SELECT	ST.sprint_id		AS [sprint_id],
			'task'				AS [type],
			ST.task_id			AS [item_id],
			ST.sprintStatus_id	AS [sprintStatus_id],
			ST.taskLead_id		AS [taskLead_id],
			(SELECT TOP 1 T.storypoints
			FROM	SCRM_tasks AS T
			WHERE	T.id=ST.task_id) AS [storypoints]
	FROM	SCRM_sprintTasks AS ST